const button = document.getElementById('ouvreMoi');
const image = document.getElementById('imageCachee');

// Fonction pour changer l'image en fonction de l'URL fournie
function changerImage(nouvelleImage) {
    image.src = nouvelleImage;
}

// Écoutez le clic sur le bouton pour changer l'image
button.addEventListener('click', () => {
    button.classList.add('button-clicked');
    
    // Changez l'image en utilisant l'URL de votre choix
    changerImage("GG.webp");
});
